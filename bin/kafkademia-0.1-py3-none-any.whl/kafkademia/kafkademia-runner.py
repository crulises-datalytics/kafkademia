from kafkademia.kafkademia import main

if __name__ == "__main__":    
    parser = argparse.ArgumentParser()
    parser.add_argument("--topico", type=str)
    parser.add_argument("--bootstrap_server", type=str)
    parser.add_argument("--n", type=str)
    parser.add_argument("--ej", type=bool)
    parser.add_argument("--productor_consumidor", type=int)
    args = vars(parser.parse_args())

    main(**args)